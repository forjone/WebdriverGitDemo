package com.demo.day6;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

/**
 * Created by thinkpad on 2017/1/12.
 */
public class SendEmail extends BaseCaseBroswer {
    @Test
    public void sendEmailFile() throws InterruptedException {
        driverChrome.get("http://mail.163.com/");
        EmailLoginCase.loginEmail(driverChrome,"dreamingxuanyu","wclggf9016");
        Thread.sleep(50000);
    }
}
